MAGDALENA LEARNING HUB – OFFLINE VERSION 5
Teacher Announcements + Teacher-Added Subjects + Quiz QR Codes

NEW IN VERSION 5
- Teacher can post, publish, and delete announcements.
- Learners see teacher announcements in the Announcements page.
- Teacher can add custom subjects with name, icon, and description.
- Teacher-added subjects automatically appear in the learner Subjects and teacher quiz builder.
- Teacher can generate a QR code for each teacher-created quiz.
- Every custom quiz receives a manual quiz code (MLH-XXXXXX) for offline classroom use.
- Learners can enter the manual quiz code to open a quiz on the same device.
- QR links support ?quiz=QUIZ_ID and can automatically open a quiz when the app is hosted on a web server/local network.
- Existing learner-progress dashboard remains included.
- Quiz attempt records, announcements, subjects, accounts, and quizzes are stored in localStorage.

DEFAULT ACCOUNTS
Teacher: teacher / Teacher123
Learner: learner / Learner123

QR / MULTI-DEVICE NOTE
The app remains localStorage-based. For a learner on another device to scan and open a quiz, the app must be hosted on a reachable web server/local network. The displayed QR image currently uses an online QR image service, so generating the QR graphic itself requires internet access. The manual quiz code is available when working fully offline.

For true school-wide monitoring across many devices, deploy the next version with a Node.js backend + database and a shared teacher/learner account system.

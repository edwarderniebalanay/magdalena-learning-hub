# Magdalena Learning Hub – Online Render Version

This package upgrades the Version 5 interface with a Node.js + Express API and PostgreSQL database.

## Features
- Teacher and learner login
- Online learner accounts
- PostgreSQL-backed quizzes, attempts, subjects and announcements
- Teacher dashboard API for live learner progress
- Teacher-created subjects
- Teacher announcements
- Quiz codes / QR-compatible quiz URLs
- Render Blueprint (`render.yaml`) for the web service + database

## Render deployment
1. Upload this project to a GitHub repository.
2. In Render, choose **New → Blueprint** and connect the repository.
3. Render reads `render.yaml` and creates the web service and PostgreSQL database.
4. The service uses `npm install` and `npm start`.
5. Open the generated `onrender.com` URL.

Default teacher:
- username: `teacher`
- password: `Teacher123`

## Important
The current Version 5 browser UI is preserved as the frontend foundation. The new backend is ready for the online data layer. To make every existing dashboard button use the PostgreSQL API instead of localStorage, the next frontend integration step should replace the localStorage functions with `/api/*` calls. The backend already exposes those endpoints.

For production, change the default teacher password immediately.

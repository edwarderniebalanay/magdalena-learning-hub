const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const { Pool } = require("pg");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 10000;
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) console.warn("DATABASE_URL is not set. Database features will not work until Render Postgres is connected.");

const pool = DATABASE_URL ? new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
}) : null;

app.use(express.json({limit:"2mb"}));
app.use(express.static(path.join(__dirname)));

async function initDb(){
 if(!pool) return;
 await pool.query(`
 CREATE TABLE IF NOT EXISTS users(
   id SERIAL PRIMARY KEY, role VARCHAR(20) NOT NULL DEFAULT 'learner',
   name TEXT NOT NULL, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
   created_at TIMESTAMPTZ DEFAULT NOW()
 );
 CREATE TABLE IF NOT EXISTS subjects(
   id SERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL, icon TEXT DEFAULT '📚',
   description TEXT DEFAULT '', created_at TIMESTAMPTZ DEFAULT NOW()
 );
 CREATE TABLE IF NOT EXISTS quizzes(
   id SERIAL PRIMARY KEY, title TEXT NOT NULL, subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
   code TEXT UNIQUE NOT NULL, questions JSONB NOT NULL, created_by INTEGER REFERENCES users(id),
   created_at TIMESTAMPTZ DEFAULT NOW()
 );
 CREATE TABLE IF NOT EXISTS announcements(
   id SERIAL PRIMARY KEY, title TEXT NOT NULL, message TEXT NOT NULL,
   priority TEXT DEFAULT 'normal', author_id INTEGER REFERENCES users(id), created_at TIMESTAMPTZ DEFAULT NOW()
 );
 CREATE TABLE IF NOT EXISTS attempts(
   id SERIAL PRIMARY KEY, learner_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
   quiz_id INTEGER REFERENCES quizzes(id) ON DELETE CASCADE, score INTEGER NOT NULL,
   correct INTEGER NOT NULL, total INTEGER NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW()
 );
 `);
 const t=await pool.query("SELECT id FROM users WHERE username='teacher'");
 if(!t.rowCount){
   const hash=await bcrypt.hash("Teacher123",10);
   await pool.query("INSERT INTO users(role,name,username,password_hash) VALUES('teacher','Teacher','teacher',$1)",[hash]);
 }
 const subs=await pool.query("SELECT id FROM subjects LIMIT 1");
 if(!subs.rowCount){
   for(const s of [
    ["Mathematics","🔢","Numbers, algebra, measurement and problem solving"],
    ["Science","🔬","Science concepts, investigations and assessments"],
    ["English","📖","Reading, writing, grammar and communication"],
    ["Filipino","🇵🇭","Wika, pagbasa, pagsulat at panitikan"],
    ["Araling Panlipunan","🌏","Kasaysayan, heograpiya at lipunan"],
    ["MAPEH","🎨","Music, Arts, Physical Education and Health"],
    ["TLE","🛠️","Technology and livelihood education"],
    ["ESP","💛","Edukasyon sa pagpapakatao"]
   ]) await pool.query("INSERT INTO subjects(name,icon,description) VALUES($1,$2,$3) ON CONFLICT(name) DO NOTHING",s);
 }
}
function auth(req,res,next){
 const token=req.headers.authorization?.replace("Bearer ","");
 if(!token) return res.status(401).json({error:"Login required"});
 pool.query("SELECT id,role,name,username FROM users WHERE id=$1",[Number(token)])
 .then(r=>{if(!r.rowCount)return res.status(401).json({error:"Invalid session"});req.user=r.rows[0];next()})
 .catch(()=>res.status(500).json({error:"Database error"}));
}
function teacher(req,res,next){if(req.user.role!=="teacher")return res.status(403).json({error:"Teacher access required"});next()}

app.post("/api/auth/login", async(req,res)=>{
 try{
  const {username,password}=req.body||{};
  const r=await pool.query("SELECT * FROM users WHERE LOWER(username)=LOWER($1)",[username||""]);
  if(!r.rowCount || !(await bcrypt.compare(password||"",r.rows[0].password_hash))) return res.status(401).json({error:"Invalid username or password"});
  const u=r.rows[0]; res.json({token:String(u.id),user:{id:u.id,role:u.role,name:u.name,username:u.username}});
 }catch(e){res.status(500).json({error:e.message})}
});
app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/subjects",async(req,res)=>{try{res.json((await pool.query("SELECT * FROM subjects ORDER BY name")).rows)}catch(e){res.status(500).json({error:e.message})}});
app.post("/api/subjects",auth,teacher,async(req,res)=>{
 try{const {name,icon,description}=req.body;const r=await pool.query("INSERT INTO subjects(name,icon,description) VALUES($1,$2,$3) RETURNING *",[name,icon||"📚",description||""]);res.json(r.rows[0])}
 catch(e){res.status(400).json({error:e.message})}
});
app.delete("/api/subjects/:id",auth,teacher,async(req,res)=>{await pool.query("DELETE FROM subjects WHERE id=$1",[req.params.id]);res.json({ok:true})});

app.get("/api/quizzes",auth,async(req,res)=>{
 const r=await pool.query("SELECT q.id,q.title,q.code,q.questions,q.created_at,s.name subject FROM quizzes q LEFT JOIN subjects s ON s.id=q.subject_id ORDER BY q.created_at DESC");
 res.json(r.rows);
});
app.post("/api/quizzes",auth,teacher,async(req,res)=>{
 try{
  const {title,subjectId,questions}=req.body;
  const code="MLH-"+crypto.randomBytes(3).toString("hex").toUpperCase();
  const r=await pool.query("INSERT INTO quizzes(title,subject_id,code,questions,created_by) VALUES($1,$2,$3,$4,$5) RETURNING *",[title,subjectId,code,JSON.stringify(questions),req.user.id]);
  res.json(r.rows[0]);
 }catch(e){res.status(400).json({error:e.message})}
});
app.delete("/api/quizzes/:id",auth,teacher,async(req,res)=>{await pool.query("DELETE FROM quizzes WHERE id=$1",[req.params.id]);res.json({ok:true})});

app.get("/api/quizzes/code/:code",auth,async(req,res)=>{
 const r=await pool.query("SELECT q.*,s.name subject FROM quizzes q LEFT JOIN subjects s ON s.id=q.subject_id WHERE q.code=$1",[req.params.code.toUpperCase()]);
 if(!r.rowCount)return res.status(404).json({error:"Quiz not found"});res.json(r.rows[0]);
});

app.post("/api/quizzes/:id/attempts",auth,async(req,res)=>{
 try{
  const {score,correct,total}=req.body;
  const r=await pool.query("INSERT INTO attempts(learner_id,quiz_id,score,correct,total) VALUES($1,$2,$3,$4,$5) RETURNING *",[req.user.id,req.params.id,score,correct,total]);
  res.json(r.rows[0]);
 }catch(e){res.status(400).json({error:e.message})}
});

app.get("/api/announcements",auth,async(req,res)=>{res.json((await pool.query("SELECT a.*,u.name author FROM announcements a LEFT JOIN users u ON u.id=a.author_id ORDER BY a.created_at DESC")).rows)});
app.post("/api/announcements",auth,teacher,async(req,res)=>{
 const {title,message,priority}=req.body;const r=await pool.query("INSERT INTO announcements(title,message,priority,author_id) VALUES($1,$2,$3,$4) RETURNING *",[title,message,priority||"normal",req.user.id]);res.json(r.rows[0]);
});
app.delete("/api/announcements/:id",auth,teacher,async(req,res)=>{await pool.query("DELETE FROM announcements WHERE id=$1",[req.params.id]);res.json({ok:true})});

app.get("/api/dashboard/learners",auth,teacher,async(req,res)=>{
 const r=await pool.query(`
 SELECT u.id,u.name,u.username,
        COUNT(a.id)::int attempts,
        COALESCE(ROUND(AVG(a.score)),0)::int average,
        COALESCE(MAX(a.score),0)::int best,
        MAX(a.created_at) last_activity
 FROM users u LEFT JOIN attempts a ON a.learner_id=u.id
 WHERE u.role='learner' GROUP BY u.id ORDER BY u.name`);
 res.json(r.rows);
});
app.get("/api/dashboard/learners/:id",auth,teacher,async(req,res)=>{
 const u=await pool.query("SELECT id,name,username FROM users WHERE id=$1 AND role='learner'",[req.params.id]);
 const a=await pool.query("SELECT a.*,q.title,q.code,s.name subject FROM attempts a JOIN quizzes q ON q.id=a.quiz_id LEFT JOIN subjects s ON s.id=q.subject_id WHERE a.learner_id=$1 ORDER BY a.created_at DESC",[req.params.id]);
 res.json({learner:u.rows[0],attempts:a.rows});
});
app.post("/api/learners",auth,teacher,async(req,res)=>{
 try{const {name,username,password}=req.body;const hash=await bcrypt.hash(password,10);const r=await pool.query("INSERT INTO users(role,name,username,password_hash) VALUES('learner',$1,$2,$3) RETURNING id,name,username,role",[name,username,hash]);res.json(r.rows[0])}
 catch(e){res.status(400).json({error:e.message})}
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"index.html")));
initDb().then(()=>app.listen(PORT,"0.0.0.0",()=>console.log(`Learning Hub listening on ${PORT}`))).catch(e=>{console.error(e);process.exit(1)});
